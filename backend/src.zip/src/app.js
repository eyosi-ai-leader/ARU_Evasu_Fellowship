const express = require("express");

const cors = require("cors");

const helmet = require("helmet");

const morgan = require("morgan");

const cookieParser = require("cookie-parser");

const healthRoutes = require("./routes/healthRoutes");

const authRoutes = require("./routes/authRoutes");

const memberRoutes = require("./routes/memberRoutes");

const dashboardRoutes = require("./routes/dashboardRoutes");

const ministryRoutes = require("./routes/ministryRoutes");

const churchAIRoutes = require("./routes/churchAIRoutes");

const prayerRequestRoutes = require("./routes/prayerRequestRoutes");

const profileRoutes = require("./routes/profileRoutes");

const announcementRoutes = require("./routes/announcementRoutes");

const inboxRoutes = require("./routes/inboxRoutes");

const memberAccessRoutes = require("./routes/memberAccessRoutes");

const invitationRoutes = require("./routes/invitationRoutes");

const eventRoutes = require("./routes/eventRoutes");

const publicEventRoutes = require("./routes/publicEventRoutes");

// NEW: public list of campus fellowships and their departments
const fellowshipRoutes = require("./routes/fellowshipRoutes");

const accessRoutes = require("./routes/accessRoutes");

const leadershipRoutes = require("./routes/leadershipRoutes");

const smallGroupRoutes = require("./routes/smallGroupRoutes");


const app = express();

// Security

app.use(helmet());

// Enable CORS

app.use(cors());

// Parse JSON requests

app.use(express.json());

// Parse form data

app.use(
  express.urlencoded({
    extended: true,
  })
);

// Parse cookies

app.use(cookieParser());

// HTTP request logger

app.use(morgan("dev"));

// Routes

app.use("/api/health", healthRoutes);

app.use("/api/auth", authRoutes);

// NEW: used by the registration form (no login needed)
app.use("/api/fellowships", fellowshipRoutes);

app.use("/api/members", memberRoutes);

app.use("/api/dashboard", dashboardRoutes);

app.use("/api/ministries", ministryRoutes);

app.use("/api/church-ai", churchAIRoutes);

app.use("/api/prayer-requests", prayerRequestRoutes);

app.use("/api/profile", profileRoutes);

app.use("/api/announcements", announcementRoutes);

app.use("/api/inbox", inboxRoutes);

app.use("/api/member-access", memberAccessRoutes);

app.use("/api/invitations", invitationRoutes);

app.use("/api/events", eventRoutes);

app.use("/api/public/events", publicEventRoutes);

app.use("/api/me", accessRoutes);

app.use("/api/leadership", leadershipRoutes);

app.use("/api/small-groups", smallGroupRoutes);
/**
 * Global Error Handler
 *
 * Handles:
 * - Multer file size errors
 * - Invalid image type errors
 * - Service errors
 * - Controller errors
 * - Unexpected server errors
 */
app.use((error, req, res, next) => {
  console.error(
    "❌ Error:",
    error
  );

  /**
   * Profile image exceeds 10 MB
   */
  if (error.code === "LIMIT_FILE_SIZE") {
    return res.status(400).json({
      success: false,
      message:
        "Profile image must not exceed 10 MB.",
    });
  }

  /**
   * Invalid profile image type
   */
  if (
    error.message ===
    "Only JPG, PNG, and WEBP images are allowed."
  ) {
    return res.status(400).json({
      success: false,
      message: error.message,
    });
  }

  /**
   * General application error
   */
  return res.status(
    error.statusCode || 500
  ).json({
    success: false,
    message:
      error.message ||
      "Internal server error.",
  });
});

/**
 * 404 Handler
 */
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "Route not found",
  });
});

module.exports = app;