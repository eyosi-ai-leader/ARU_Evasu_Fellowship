const { body, param } = require("express-validator");

const { profileRules } = require("./memberProfileRules");
const { MIN_ROLE_ID, MAX_ROLE_ID } = require("../constants/roles");

/**
 * Validate member ID
 */
const memberIdValidator = [
  param("id")
    .isInt({ min: 1 })
    .withMessage(
      "Member ID must be a positive integer"
    ),
];

/**
 * Validate create member request
 *
 * Member number is intentionally NOT included.
 * It is generated automatically by the backend.
 *
 * There is no password: the member chooses their own through
 * the invitation link that is emailed to them.
 *
 * The campus fellowship (fellowshipId) is required.
 */
const createMemberValidator = [
  body("firstName")
    .trim()
    .notEmpty()
    .withMessage(
      "First name is required"
    )
    .isLength({ max: 100 })
    .withMessage(
      "First name must not exceed 100 characters"
    ),

  body("middleName")
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 100 })
    .withMessage(
      "Middle name must not exceed 100 characters"
    ),

  body("lastName")
    .trim()
    .notEmpty()
    .withMessage(
      "Last name is required"
    )
    .isLength({ max: 100 })
    .withMessage(
      "Last name must not exceed 100 characters"
    ),

  body("email")
    .trim()
    .notEmpty()
    .withMessage(
      "Email is required"
    )
    .isEmail()
    .withMessage(
      "Please provide a valid email address"
    )
    .isLength({ max: 255 })
    .withMessage(
      "Email must not exceed 255 characters"
    ),

  body("phone")
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 20 })
    .withMessage(
      "Phone must not exceed 20 characters"
    ),

  body("address")
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 255 })
    .withMessage(
      "Address must not exceed 255 characters"
    ),

  body("roleId")
    .isInt({ min: MIN_ROLE_ID, max: MAX_ROLE_ID })
    .withMessage(
      `Role ID must be between ${MIN_ROLE_ID} and ${MAX_ROLE_ID}`
    ),

  body("gender")
    .optional({ nullable: true })
    .isIn(["Male", "Female"])
    .withMessage(
      "Gender must be Male or Female"
    ),

  body("dateOfBirth")
    .optional({ nullable: true })
    .isISO8601()
    .withMessage(
      "Date of birth must be a valid date"
    ),

  body("baptismDate")
    .optional({ nullable: true })
    .isISO8601()
    .withMessage(
      "Baptism date must be a valid date"
    ),

  body("status")
    .optional()
    .isIn(["Active", "Inactive"])
    .withMessage(
      "Status must be Active or Inactive"
    ),

  /*
   * Campus, department, graduation year, hometown, emergency contact,
   * spiritual background and permission to contact after graduation.
   */
  ...profileRules(),
];

/**
 * Validate update member request
 *
 * Member number is intentionally NOT included.
 * It cannot be changed after creation.
 *
 * Every fellowship field is optional here: only the fields that are
 * sent are checked.
 */
const updateMemberValidator = [
  ...memberIdValidator,

  body("firstName")
    .optional()
    .trim()
    .notEmpty()
    .withMessage(
      "First name cannot be empty"
    )
    .isLength({ max: 100 })
    .withMessage(
      "First name must not exceed 100 characters"
    ),

  body("middleName")
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 100 })
    .withMessage(
      "Middle name must not exceed 100 characters"
    ),

  body("lastName")
    .optional()
    .trim()
    .notEmpty()
    .withMessage(
      "Last name cannot be empty"
    )
    .isLength({ max: 100 })
    .withMessage(
      "Last name must not exceed 100 characters"
    ),

  body("email")
    .optional()
    .trim()
    .isEmail()
    .withMessage(
      "Please provide a valid email address"
    )
    .isLength({ max: 255 })
    .withMessage(
      "Email must not exceed 255 characters"
    ),

  body("roleId")
    .optional()
    .isInt({ min: MIN_ROLE_ID, max: MAX_ROLE_ID })
    .withMessage(
      `Role ID must be between ${MIN_ROLE_ID} and ${MAX_ROLE_ID}`
    ),

  body("gender")
    .optional({ nullable: true })
    .isIn(["Male", "Female"])
    .withMessage(
      "Gender must be Male or Female"
    ),

  body("phone")
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 20 })
    .withMessage(
      "Phone must not exceed 20 characters"
    ),

  body("dateOfBirth")
    .optional({ nullable: true })
    .isISO8601()
    .withMessage(
      "Date of birth must be a valid date"
    ),

  body("baptismDate")
    .optional({ nullable: true })
    .isISO8601()
    .withMessage(
      "Baptism date must be a valid date"
    ),

  body("address")
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 255 })
    .withMessage(
      "Address must not exceed 255 characters"
    ),

  body("status")
    .optional()
    .isIn(["Active", "Inactive"])
    .withMessage(
      "Status must be Active or Inactive"
    ),

  ...profileRules({ partial: true }),
];

module.exports = {
  memberIdValidator,
  createMemberValidator,
  updateMemberValidator,
};
